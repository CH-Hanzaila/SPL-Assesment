#include<iostream>
#include<string>
using namespace std;

/*---------------User---------------*/
class User
{
public:
	User(string, string, string, string);
	User();
	~User();
	//member functions
	virtual void getProfile() = 0;   //pure virtual function -- abstrct class

	void setFirstName(string);  
	void setLastName(string);
	void setPassword(string);
	void setUserName(string);

	string getFirstName();
	string getLastName();
	string getPassword();
	string getUserName();

	bool setSignIn(string, string); 
	bool setSignOut();
	

protected:
	//members variable
	string firstName, lastName, password, userName;
	bool signin, signout;
};

User::User() {
	this->firstName = "";
	this->lastName = "";
	this->password = "";
	this->userName = "";
}

User::User(string firstName, string lastName, string password, string userName) {
	this->firstName = firstName;
	this->lastName = lastName;
	this->password = password;
	this->userName = userName;
}

bool User::setSignIn(string userName, string password) {
	if (this->userName==userName&& this->password==password)
	{
		this->signin = true;
		return this->signin;  //successfully signin
	}
	else {
		this->signin = false;
		return this->signin;    //incorrect authentication
	}
}
bool User::setSignOut() {
	if (this->signin==true)
	{
		this->signin = false;
		return true;    //signout successfully
	}
	else {
		return false;   //if user already signout
	}
}

void User::setFirstName(string firstName) {
	this->firstName = firstName;
}
void User::setLastName(string lastName) {
	this->lastName = lastName;
}
void User::setPassword(string password) {
	this->password = password;
}
void User::setUserName(string userName) {
	this->userName = userName;
}

string User::getFirstName() {
	return this->firstName;
}
string User::getLastName() {
	return this->lastName;
}
string User::getPassword() {
	return this->password;
}
string User::getUserName() {
	return this->userName;
}


/*----------------------------------------*/
/*---------------Student---------------*/

class Student:public User
{
public:
    //constructor
	Student() {
		rollNumber = 0;
		firstName = "";
		lastName = "";
		password = "";
		userName = "";
		this->totalCourses = 0;
	}

	//constructor to add new students
	Student(int rollNumber, string status, string firstName, string lastName, string password, string userName):User(firstName, lastName,password,userName){
		this->rollNumber = rollNumber;
		for (int i = 0; i < this->status->length(); i++)
		{
			if (this->status[i] == status) {
				this->statusSet = status;
				break;
			}
			else {
				this->statusSet = "";
			}

		}
		this->totalCourses = 0;
	}

	

	~Student();  //destructor


	//member functions
	void setRollNumber(int);
	void setStatus(string);

	int getRollNumber();
	string getStatus();

	//enroll the course 
	bool enrollCourse(Course c) {
		bool check = false;
		if (totalCourses <= 5) {   //maximum 5 courses enrolled per std
			for (int i = 0; i < totalCourses; i++) //check for already enrolled or not
			{
				if (course[i].getCourseCode() == c.getCourseCode()) {
					cout << "\nCourse already enrolled\n";
					check = true;
					break;
				}
			}
			if (check == false) {
				course[totalCourses] = c; //course added
				course[totalCourses].setEnrolledStudents(getFirstName() + " " + getLastName());
				return true;
			}
			else {
				return false;  //already added
			}
		}
		else {
			cout << "You have enrolled maximum courses\n";
			return false;
		}
	}

	//set obtained marks to course assignment, it'll just add instructor, and didn't access student
	void setObtainedMarks(int marks, int assignmentNo, Course c) {
		int chk = checkCourseEnrolled(c);
		if (chk > -1) {
			if (course[chk].getCountAssignment() >= assignmentNo) {
				this->obtainedMarks[assignmentNo][0] = marks;
				cout << "Set Obtained Marks Successfully" << endl;
			}
		}
		else {
			cout << "Course not found" << endl;
		}
		
	}

	//student view the marks course
	void viewMarks(Course c) {
		int chk = checkCourseEnrolled(c);
		if (chk > -1) {
			int chkAssignments = course[chk].getCountAssignment();
			if (chkAssignments > 0) {
				cout << "Marks of assignment wise: \n";
				for (int i = 0; i < chkAssignments; i++)
				{
					cout << i + 1 << ": " << obtainedMarks[i][0] << endl;
				}
			}
			else {
				cout << "No assignment found\n";
			}
		}
		else {
			cout << "Course not enrolled\n";
		}
	}

	//view all the resources of course
	void viewResources(Course c) {
		int chk = checkCourseEnrolled(c);
		if (chk > -1) {
			if (course[chk].getResources() != "") {
				cout << "Here is the resources of " << course[chk].getCourseName() << endl;
				course[chk].getResources();
			}
			else {
				cout << "No resource added\n";
			}
		}
		else {
			cout << "Course not enrolled\n";
		}
	}

	//check the student it may enrolled or not
	int checkCourseEnrolled(Course c) {
		for (int i = 0; i < totalCourses; i++)
		{
			if (course[i].getCourseCode() == c.getCourseCode()) {
				return i;
			}
		}
		return -1;
	}

	//get marks of course
	int getMarks(Course c) {
		int chk = checkCourseEnrolled(c);
		if (chk>-1) {
			return obtainedMarks[chk][0];
		}
		return 0;
	}

	//view the rosters of course
	void viewRoster(Course c) {
		int chk = checkCourseEnrolled(c);
		if (chk > -1) {
			cout << "Instructor of Course: " << course[chk].getInstructorName() << endl;
			cout << "\nList of Students enrolled in " << course[chk].getCourseName() << endl;
			cout << course[chk].getEnrolledStudents() << endl;
		}
		else {
			cout << "Course not enrolled\n";
		}
	}

	//view all the assignments of course
	void viewAssignmentsOfCourse(Course c) {
		int chk = checkCourseEnrolled(c);
		if (chk > -1) {
			if (course[chk].getAssignments() != "") {
				cout << course[chk].getAssignments() << endl;
			}
			else {
				cout << "No assignment exist\n";
			}
		}
		else {
			cout << "\nCourse not enrolled\n";
		}
	}



	//member  from abstract
	void getProfile();

private:
	//member variables
	int rollNumber;
	string status[4] = { "freshman", "sophomore", "junior", "senior" };
	string statusSet;
	unsigned int totalCourses;
	Course course[5];   //maximum 5 courses added per std
	int obtainedMarks[][1];
};

Student::~Student()
{
	//delete[]course;
}

//definition
void Student::setRollNumber(int rollNumber) {
	if (rollNumber != 0) {
		this->rollNumber = rollNumber;
	}
	else {
		cout << "\nField is empty\n";
		this->rollNumber = 0;
	}
}

//set the status of student
void Student::setStatus(string status) {
	for (int i = 0; i < this->status->length(); i++)
	{
		if (this->status[i] == status) {
			this->statusSet = status;
			break;
		}
		else {
			this->statusSet = "";
		}
	}
	
}

int Student::getRollNumber() {
	return this->rollNumber;
}

string Student::getStatus() {
	if (this->statusSet != "") {
		return this->statusSet;
	}
	else {
		return ("No Status");
	}
}

//abstract member --- override
//function definition, because in abstract class, this function has no its definition
void Student::getProfile() {
	cout << getFirstName() + " " + getLastName() << " is a " << getStatus() << " student at LUMS\n";
}


/*----------------------------------------*/
/*---------------Assignment---------------*/


class Assignment
{
public:
	Assignment(string assignmentName, string dueDate, int totalMarks) {   //constrcutor for create new assignment 
		this->assignmentName = assignmentName;
		this->dueDate = dueDate;
		this->totalMarks = totalMarks;
	}

	Assignment() {    //constructor for create by default
		this->assignmentName = "";
		this->dueDate = "";
		this->totalMarks = 0;
	}

	void setDueDate(string dueDate) {    //for update dueDate if need
		this->dueDate = dueDate;
	}

	string getAssignmentName() {
		return this->assignmentName;
	}
	string getDueDate() {
		return this->dueDate;
	}
	int getTotalMarks() {
		return this->totalMarks;
	}

	
	~Assignment();     //destructor

private:
	string assignmentName, dueDate;
	int totalMarks;
};

Assignment::~Assignment()
{
}

/*--------Course ------------*/

//course class
class Course
{
public:
	  //constructor
	Course() {      //by default constructor
		this->courseName = "";
		this->courseCode = "";
		this->offeringSchool = "";
		this->countAssignment = 0;
		this->totalStudents = 0;
		this->enrolledStudents = "";
	}
	Course(string, string, string, int, Instructor);    //for creating new courses
	~Course();  //destructor


	//member functions
	void setCourseName(string courseName) {   //setter functions
		this->courseName = courseName;
	}
	void setCourseCode(string courseCode) {
		this->courseCode = courseCode;
	}
	void setOfferingSchool(string offeringSchool) {
		this->offeringSchool = offeringSchool;
	}
	void setCapacity(int capacity) {
		if (capacity >= 0) {
			this->capacity = capacity;
		}
		else {
			this-> capacity = 0;
			cout << "\nInvalid Capacity\n";
		}
	}

	string getCourseName() {    //getter function
		return this->courseName;
	}
	string getCourseCode() {
		return this->courseCode;
	}
	string getOfferingSchool() {
		return this->offeringSchool;
	}
	int getCapacity() {
		return this->capacity;
	}

	//count the assignment of each courses for iteration on view assignment
	int getCountAssignment() {
		return this->countAssignment;
	}

	//get total students enrolled in course
	int getTotalStudents() {
		return this->totalStudents;
	}
	//when assignemnt create it increase by 1 to check how many assignments in course
	void setCountAssignment() {
		this->countAssignment++;
	}
	//if we display the list of enrolled students
	void setEnrolledStudents(string name) {      
		this->enrolledStudents += (name + "\n");
		totalStudents++;
	}
	//get number of enrolled students
	string getEnrolledStudents() {
		this->enrolledStudents;
	}
	//set resources, it will concatenate the resources
	void setResources(string res) {
		resources += (res + "\n");
	}
	//get resource
	string getResources() {
		return this->resources;
	}
	//set the instructor name if change instrcutor of course
	void setInstructorName(Instructor inst) {
		this->instructor = inst;
	}

	//display the instructure name for roster
	string getInstructorName() {
		string str = "";
		str = instructor.getFirstName() + " " + instructor.getLastName();
	}

	//add new assignment of course
	void addAssignment(string assignmentName, string dueDate, int totalMarks) {
		Assignment* temp = new Assignment(assignmentName, dueDate, totalMarks);
		ass = temp;
		countAssignment++;
		cout << "Assignment added successfully" << endl;
	}
	//get the assignment detail
	string getAssignments() {
		string temp = "";
		if (countAssignment > 0) {
			stringstream ss;
			string numtemp = "";
			for (int i = 0; i < countAssignment; i++)
			{
				ss << ass[i].getTotalMarks();
				ss >> numtemp;
				temp = temp + ("Assignment Name: " + ass[i].getAssignmentName() + "\nDue Date: " + ass[i].getDueDate() + "\nTotal Marks: " + numtemp + "\n");
			}
			return temp;
		}
		else {
			return temp;
		}
	}


private:
	//member variables
	string courseName, courseCode, offeringSchool;
	unsigned int capacity;

	string resources;
	string enrolledStudents;
	int countAssignment;
	int totalStudents;
	Assignment *ass;   //assignments for course
	Instructor instructor;  //a course has one instructor
};


//definition of constructor to add new course
Course::Course(string courseName, string courseCode, string offeringSchool, int capacity, Instructor instructor)
{
	this->courseName = courseName;
	this->courseCode = courseCode;
	this->offeringSchool = offeringSchool;
	if (capacity >= 0) {
		this->capacity = capacity;
	}
	else {
		this->capacity = 0;

		cout << "\nInvalid Capacity\n";
	}
	this->countAssignment = 0;
	this->totalStudents = 0;
	this->enrolledStudents = "";
	this->instructor = instructor;
	
}

//destructor
Course::~Course()
{
	delete ass;   //delete the assignment pointer if course deleted
}

/*---------------------------------*/
/*-----Instructor-----------------*/

class Instructor:public User
{
public:
	   //constructor to add new instructor
	Instructor(string designation, string qualification, int instructorCode, string firstName, string lastName, string password, string userName) :User(firstName, lastName, password, userName) {
		this->designation = designation;
		this->qualification = qualification;
		if (instructorCode > 0) {
			this->instructorCode = instructorCode;
		}
		else {
			this->instructorCode = 0;
			cout << "Invalid Instructor Code\n";
		}
	}

	//by default constructor to make pointer on another classes
	Instructor() {
		this->designation = "";
		this->qualification = "";
		
		this->instructorCode = 0;
			
	}
	~Instructor();  //destructor


	//member functions, setter getter
	string getDesignation() {
		this->designation;
	}
	string getQualification() {
		this->qualification;
	}
	int getInstructorCode() {
		return this->instructorCode;
	}

	//member  from abstract
	void getProfile();
	//find the student it enrolled or not just check
	int findStudent(Student std, Course c) {
		for (int i = 0; i < c.getTotalStudents(); i++)
		{
			if (student[i].getRollNumber()==std.getRollNumber()) {
				if (std.checkCourseEnrolled(c) > 0) {
					return i;
				}
				
			}
		}
		return -1;
	}
	
	//add the marks to student of his course
	void addMarks(Student std, int marks, Course c, int assNo) {
		unsigned int chk = findStudent(std, course);
		if (chk >= 0) {
			student[chk].setObtainedMarks(marks, assNo, c);
			cout << "Marks added successfully" << endl;
		}
		else {
			cout << "\nStudent not found\n";
		}
	}
	//view marks of all students of that course
	void viewMarks(Course c) {
		cout << "Marks of all students: \n";
		for (int i = 0; i < course.getTotalStudents(); i++)
		{
			cout << "RollNo: " << student[i].getRollNumber() << "\tMarks: " << student[i].getMarks(c) << endl;
		}
	}

	//add the resource of course that teach instructor
	void addResource(string res) {
		course.setResources(res);
	}
	//view resources
	void viewResource() {
		cout << "Resource of " << course.getCourseName() << ": \n";
		cout << course.getResources() << endl;
	}

	//view rosters, show all the students in course and instructor name
	void viewRoster() {
		cout << "Course: " << course.getCourseName() << ", Instructor Name: " << course.getInstructorName() << endl;
		cout << course.getEnrolledStudents() << endl;
	}
	//add the new assignment in that course which instructor teach
	void addAssignment(string assignmentName, string dueDate, int totalMarks) {
		course.addAssignment(assignmentName, dueDate, totalMarks);
	}
	//view all assignment of course which instructor teach
	void viewAssignment() {
		cout << "Assignments of " << course.getCourseName() << " course are: \n" << course.getAssignments();
	}

private:
	//member variables
	string designation, qualification;
	int instructorCode;
	Course course;
	Student *student;
};


Instructor::~Instructor()
{
	delete student;  //free the space after deleting instructor
}

void Instructor::getProfile() {
	cout << getFirstName() + " " + getLastName() << " is " << getDesignation() << " at LUMS\n";
}