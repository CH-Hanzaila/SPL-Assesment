#include<iostream>
using namespace std;

int Memo(int array1[], int number1) {
	if (number1 == 0 || number1 == 1) {
		return 1;
	}
	else {
		return (array1[number1 - 2] + array1[number1 - 1]);
	}
}


int* fibonnaci(int number1) 
{
	static int* fib = new int[number1 + 1];
	fib[0] = 0;
	for (int num = 1; num < number1 + 1; num++)
	{
		fib[num] = Memo(fib, num);
	}

	return fib;
}



int main() {
	int number1 = 9, num = 0;
	int* f;
	f = fibonnaci(number1);
	while (num < (number1 + 1))
	{
		cout << f[num] << "  ";
		num++;
	}

	return 0;
}



/* Memorization
	With this we can save the previous computation results and it is used for the improvemennt of the performance 
	and to the solve recursive problems we use this technique. 
*/