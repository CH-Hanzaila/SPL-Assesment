#include<iostream>
#include<cmath>
#include<algorithm>
using namespace std;

int length(int array1[]) 
{  
	/*By function parameters requirement there is only one parameter for findAMin(array1[]) function.*/

	int counter = 0;
	while (array1[counter] >= 0)
	{
		counter++;
	}
	return counter;
}

int findAMin(int array1[])
{      //main function
	unsigned int len = length(array1);  // find length
	int aMin = 0;
	if (len != 0) {
		aMin = abs(array1[len - 1] - array1[0]);
	}
	for (int i = 0; i < len; i++)
	{
		aMin = min(aMin, abs(array1[i] - array1[i + 1]));
	}
	return aMin;
}

int main() {
	int array1[] = { 10, 12, 13, 15, 10 };
	cout << "Minimum Absolute Difference " << findAMin(array1) << endl;

	return 0;
}