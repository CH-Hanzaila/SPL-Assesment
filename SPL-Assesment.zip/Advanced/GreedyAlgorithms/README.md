# Greedy Algorithms:

## Problem 1: Find Minimum Absolute Difference of Adjacent Elements In An Array.

    Given an array of elements find the minimum absolute difference
    between adjacent elements in an array.

    Example:
        Input : arr[] = {10, 12, 13, 15, 10}

        Output : 0
        Explanation: |10 - 10| = 0 which is the
        minimum possible.

        Function Description

        Complete the function findAbsMin with following details:

        findAbsMin has the following parameter(s):
        int a[n]: the array of elements

        Returns
        int a': Minimum Absolute Difference


    Command/Script to Run Problem 1: ________________
1. Open dev c++ or any other C++ compiler.
2. Copy the code in .cpp file and paste it on compiler
3. Run the program 

