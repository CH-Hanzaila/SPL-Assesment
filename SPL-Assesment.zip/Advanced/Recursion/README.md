# Recursion Problems:

## Problem 1: Calculate Mean of An Array using Recursion.

    Given an array of elements find the mean of the elements
    in that array using recursion.

    Example:
        Input : arr[] = {10, 12, 14, 16, 18}
        Output : 14
        Function Description

        Complete the function calMean with following details:

        calMean has the following parameter(s):
        int a[n]: the array of elements

        Returns
        int a': Mean of the elements


    Command/Script to Run Problem 1: ________________
1. Open dev c++ or any other C++ compiler.
2. Copy the code in .cpp file and paste it on compiler
3. Run the program 
